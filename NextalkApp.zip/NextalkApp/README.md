# NextalkApp
A minimal starter Android Studio project (Compose) generated for you.
